import React from 'react';
export const BugSort = () => (
    <section className="sort">
        <label htmlFor="">Order By :</label>
        <select name="" id="">
            <option value=""></option>
            <option value=""></option>
        </select>
        <label htmlFor="">Descending : </label>
        <input type="checkbox" name="" id="" />
    </section>
);